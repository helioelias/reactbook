demo of `whinepad3` is available at https://www.whinepad.com/

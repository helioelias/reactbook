/* @flow */

import React from 'react';

let Logo = () => <div className="Logo"/>;

export default Logo

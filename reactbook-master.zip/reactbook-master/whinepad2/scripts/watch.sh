watch "sh scripts/build.sh" js/source/ js/__tests__/ css/
